import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class GlossaryTest {

    /*
     * Testing readInput
     */

    @Test
    public void testReadInput_emptyFile() {
        Map<String, String> termsAndDefinitions = Glossary
                .readInput("Emptyfile.txt");

        Map<String, String> expectedOutput = termsAndDefinitions.newInstance();

        assertEquals(expectedOutput, termsAndDefinitions);
    }

    @Test
    public void testReadInput_sampleFile() {
        Map<String, String> termsAndDefinitions = Glossary
                .readInput("terms.txt");

        Map<String, String> expectedOutput = termsAndDefinitions.newInstance();
        expectedOutput.add("meaning",
                "something that one wishes to convey, especially by language");
        expectedOutput.add("term", "a word whose definition is in a glossary");
        expectedOutput.add("word",
                "a string of characters in a language, which has at least one character");
        expectedOutput.add("definition",
                "a sequence of words that gives meaning to a term");
        expectedOutput.add("glossary",
                "a list of difficult or specialized terms, with their definitions, usually near the end of a book");
        expectedOutput.add("language",
                "a set of strings of characters, each of which has meaning");
        expectedOutput.add("book", "a printed or written literary work");

        assertEquals(expectedOutput, termsAndDefinitions);
    }

    /*
     * Testing sortedTerms
     */
    @Test
    public void testSortedTerms_emptyMap() {
        Map<String, String> termsAndDefinitions = new Map1L<>();

        Map<String, String> expectedOutput = termsAndDefinitions.newInstance();

        Queue<String> sortedTerms = Glossary.sortedTerms(termsAndDefinitions);
        Queue<String> expectedSortedTerms = sortedTerms.newInstance();

        assertEquals(sortedTerms, expectedSortedTerms);
        assertEquals(expectedOutput, termsAndDefinitions);
    }

    @Test
    public void testSortedTerms_sampleFile() {
        Map<String, String> termsAndDefinitions = Glossary
                .readInput("terms.txt");

        Map<String, String> expectedOutput = termsAndDefinitions.newInstance();
        expectedOutput.add("meaning",
                "something that one wishes to convey, especially by language");
        expectedOutput.add("term", "a word whose definition is in a glossary");
        expectedOutput.add("word",
                "a string of characters in a language, which has at least one character");
        expectedOutput.add("definition",
                "a sequence of words that gives meaning to a term");
        expectedOutput.add("glossary",
                "a list of difficult or specialized terms, with their definitions, usually near the end of a book");
        expectedOutput.add("language",
                "a set of strings of characters, each of which has meaning");
        expectedOutput.add("book", "a printed or written literary work");

        Queue<String> sortedTerms = Glossary.sortedTerms(termsAndDefinitions);
        Queue<String> expectedSortedTerms = sortedTerms.newInstance();

        expectedSortedTerms.enqueue("book");
        expectedSortedTerms.enqueue("definition");
        expectedSortedTerms.enqueue("glossary");
        expectedSortedTerms.enqueue("language");
        expectedSortedTerms.enqueue("meaning");
        expectedSortedTerms.enqueue("term");
        expectedSortedTerms.enqueue("word");

        assertEquals(sortedTerms, expectedSortedTerms);
        assertEquals(expectedOutput, termsAndDefinitions);
    }

    /*
     * Testing processDefinition
     */

    @Test
    public void testProcessDefinition_emptyInputs() {
        String term = "";
        Map<String, String> testMap = new Map1L<>();
        SimpleWriter out = new SimpleWriter1L("testFile.html");

        Glossary.processDefinition(term, testMap, out);
        SimpleReader input = new SimpleReader1L("testFile.html");
        String definition = "";

        while (!input.atEOS()) {
            definition += input.nextLine();
        }

        String expectedTerm = "";
        Map<String, String> expectedMap = testMap.newInstance();
        String expectedDefinition = "<p></p>";

        assertEquals(expectedTerm, term);
        assertEquals(expectedMap, testMap);
        assertEquals(expectedDefinition, definition);
    }

    @Test
    public void testProcessDefinition_sampleFile() {
        String term = "meaning";
        Map<String, String> testMap = Glossary.readInput("terms.txt");
        SimpleWriter out = new SimpleWriter1L("testFile.txt");

        Glossary.processDefinition(term, testMap, out);
        SimpleReader input = new SimpleReader1L("testFile.txt");
        String definition = "";

        while (!input.atEOS()) {
            definition += input.nextLine();
        }

        String expectedTerm = "meaning";
        Map<String, String> expectedMap = Glossary.readInput("terms.txt");
        String expectedDefinition = "<p> something that one wishes to convey, especially by <a href = language.html>language</a></p>";

        assertEquals(expectedTerm, term);
        assertEquals(expectedMap, testMap);
        assertEquals(expectedDefinition, definition);
    }

    /*
     * Testing processSingleTerm
     */

    @Test
    public void testProcessSingleTerm_emptyFile() {
        String fileName = "emptyFile.html";
        String term = "";
        Map<String, String> termsAndDefinitions = new Map1L<>();
        Queue<String> sortedTerms = new Queue1L<>();
        Glossary.processSingleTerm(fileName, term, termsAndDefinitions,
                sortedTerms);

        SimpleReader input = new SimpleReader1L("emptyFile.html");
        String output = "";

        while (!input.atEOS()) {
            output += input.nextLine();
        }

        String expectedFileName = "emptyFile.html";
        String expectedTerm = "";
        Map<String, String> expectedTermsAndDefinitions = termsAndDefinitions
                .newInstance();
        Queue<String> expectedSortedTerms = sortedTerms.newInstance();
        String expectedOutput = "";

        assertEquals(expectedFileName, fileName);
        assertEquals(expectedTerm, term);
        assertEquals(expectedTermsAndDefinitions, termsAndDefinitions);
        assertEquals(expectedSortedTerms, sortedTerms);
        assertEquals(expectedOutput, output);
    }

    @Test
    public void testProcessSingleTerm_sampleFile() {
        String fileName = "testFile.html";
        String term = "meaning";
        Map<String, String> termsAndDefinitions = Glossary
                .readInput("terms.txt");
        Queue<String> sortedTerms = Glossary.sortedTerms(termsAndDefinitions);
        Glossary.processSingleTerm(fileName, term, termsAndDefinitions,
                sortedTerms);

        SimpleReader input = new SimpleReader1L("testFile.html");
        String output = "";

        while (!input.atEOS()) {
            output += input.nextLine();
        }

        String expectedFileName = "testFile.html";
        String expectedTerm = "meaning";
        Map<String, String> expectedTermsAndDefinitions = Glossary
                .readInput("terms.txt");
        Queue<String> expectedSortedTerms = Glossary
                .sortedTerms(termsAndDefinitions);
        String expectedOutput = "";
        SimpleReader in = new SimpleReader1L("testSampleFile.html");

        while (!in.atEOS()) {
            expectedOutput += in.nextLine();
        }

        assertEquals(expectedFileName, fileName);
        assertEquals(expectedTerm, term);
        assertEquals(expectedTermsAndDefinitions, termsAndDefinitions);
        assertEquals(expectedSortedTerms, sortedTerms);
        assertEquals(expectedOutput, output);
    }

    /*
     * Testing processIndex
     */
    @Test
    public void testProcessIndex_emptyFile() {
        String folderName = "JUnit Tests";
        Map<String, String> termsAndDefinitions = new Map1L<>();
        Queue<String> sortedTerms = new Queue1L<>();
        Glossary.processIndex(sortedTerms, termsAndDefinitions, folderName);

        SimpleReader input = new SimpleReader1L("Junit Tests/index.html");
        String output = "";

        while (!input.atEOS()) {
            output += input.nextLine();
        }

        String expectedFolderName = "JUnit Tests";
        Map<String, String> expectedTermsAndDefinitions = termsAndDefinitions
                .newInstance();
        Queue<String> expectedSortedTerms = sortedTerms.newInstance();
        SimpleReader in = new SimpleReader1L("emptyFileProcessIndex.html");
        String expectedOutput = "";
        while (!in.atEOS()) {
            expectedOutput += in.nextLine();
        }

        assertEquals(expectedFolderName, folderName);
        assertEquals(expectedTermsAndDefinitions, termsAndDefinitions);
        assertEquals(expectedSortedTerms, sortedTerms);
        assertEquals(expectedOutput, output);
    }

    @Test
    public void testProcessIndex_sampleFile() {
        String folderName = "JUnit Tests";
        Map<String, String> termsAndDefinitions = Glossary
                .readInput("terms.txt");
        Queue<String> sortedTerms = Glossary.sortedTerms(termsAndDefinitions);
        Glossary.processIndex(sortedTerms, termsAndDefinitions, folderName);

        SimpleReader input = new SimpleReader1L("Junit Tests/index.html");
        String output = "";

        while (!input.atEOS()) {
            output += input.nextLine();
        }

        String expectedFolderName = "JUnit Tests";
        Map<String, String> expectedTermsAndDefinitions = Glossary
                .readInput("terms.txt");
        Queue<String> expectedSortedTerms = Glossary
                .sortedTerms(termsAndDefinitions);
        SimpleReader in = new SimpleReader1L("sampleFileProcessIndex.html");
        String expectedOutput = "";
        while (!in.atEOS()) {
            expectedOutput += in.nextLine();
        }

        assertEquals(expectedFolderName, folderName);
        assertEquals(expectedTermsAndDefinitions, termsAndDefinitions);
        assertEquals(expectedSortedTerms, sortedTerms);
        assertEquals(expectedOutput, output);
    }
}
