import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 *
 * @author Abd Elrahman Ibrahim
 *
 */

public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Reads the terms and the definitions from a file and returns a map with
     * the terms as the keys and the definitions as the values.
     *
     * @param fileName
     *            The file that contains the terms and their definitions
     * @return A Map<String, String> with the terms being the keys and the
     *         definitions being the values
     * @requires <pre>
     *         The file entered by the user is formatted appropriately
     * </pre>
     * @ensures The generated map contains all of the terms and definitions in
     *          the inputted file
     *
     */

    public static Map<String, String> readInput(String fileName) {
        /*
         * input is the stream for the file entered by the user
         */
        SimpleReader input = new SimpleReader1L(fileName);
        /*
         * term is the word that user defines
         */
        String term;
        /*
         * definition is the meaning of the word entered by the user
         */
        String definition;
        /*
         * emptyLine is the line proceeding the term and the definition
         */
        String emptyLine;
        /*
         * termsAndDefintions is a map with the terms as the keys and the
         * definitions as the values
         */
        Map<String, String> termsAndDefinitions = new Map1L<>();
        /*
         * Checking if the end of the file has been reached
         */
        while (!input.atEOS()) {
            term = input.nextLine();
            definition = input.nextLine();
            /*
             * Checking if the term and definition where the last terms and
             * definitions
             */
            if (!input.atEOS()) {
                emptyLine = input.nextLine();
                /*
                 * Checking if the definition has more than one line
                 */
                while (!emptyLine.equals("")) {
                    definition += " " + emptyLine;
                    emptyLine = input.nextLine();
                }
            }
            termsAndDefinitions.add(term, definition);
        }
        input.close();
        return termsAndDefinitions;
    }

    /**
     * Stores the terms from the map termsAndDefinitions into a queue and sorts
     * the queue using a comparator.
     *
     * @param termsAndDefinitions
     *            The map that contains the terms and their definitions
     * @return A Queue<String> with the terms sorted alphabetically
     *
     * @ensures The generated queue is organized alphabetically and contains all
     *          of the terms in the inputted map
     *
     */

    public static Queue<String> sortedTerms(
            Map<String, String> termsAndDefinitions) {
        /*
         * singlePair is a single pair from the Map termsAndDefinitions
         */
        Map.Pair<String, String> singlePair;
        /*
         * sortedTerms is a sorted queue of all of the terms in the Map
         * termsAndDefinitions
         */
        Queue<String> sortedTerms = new Queue1L<>();
        /*
         * testMap is a test map used to store all of the previous pairs that
         * where in termsAndDefinitions
         */
        Map<String, String> testMap = termsAndDefinitions.newInstance();
        /*
         * term is the term key in singlePair
         */
        String term;
        /*
         * Getting all of the terms from the termsAndDefinitions map and adding
         * them to the queue sortedTerms
         */
        while (termsAndDefinitions.size() > 0) {
            singlePair = termsAndDefinitions.removeAny();
            term = singlePair.key();
            sortedTerms.enqueue(term);
            testMap.add(singlePair.key(), singlePair.value());
        }

        /*
         * Sorting all of the terms in the queue sortedTerms
         */
        Comparator<String> queueComparator = new StringComparator();
        sortedTerms.sort(queueComparator);

        termsAndDefinitions.transferFrom(testMap);

        return sortedTerms;
    }

    /**
     * Outputs the index html page with the hyperlinks of each term
     * corresponding to an html file that contains the term and its definition.
     *
     * @param termsAndDefinitions
     *            The map that contains the terms and their definitions
     * @param sortedTerms
     *            A queue containing the sorted terms found in the map
     *            termsAndDefinitions
     * @param folderName
     *            The name of the folder entered by the user
     *
     * @requires The entered folderName exists, the queue sortedTerms and the
     *           map termsAndDefinitions are both formatted appropriately
     *
     * @ensures The outputted index is formatted appropriately
     *
     */
    public static void processIndex(Queue<String> sortedTerms,
            Map<String, String> termsAndDefinitions, String folderName) {

        /*
         * out is an output stream to the index
         */
        SimpleWriter out = new SimpleWriter1L(folderName + "/index.html");
        /*
         * currentTerm is the current term being inspected from the queue
         */
        String currentTerm;
        /*
         * testQueue is a queue that is used to restore all of the items in
         * sortedTerms
         */
        Queue<String> testQueue = sortedTerms.newInstance();

        out.println("<html> <head> <title> Glossary </title> </head> <body>");
        out.println("<h1><b> Glossary </b></h1>");
        out.println("<h2><b> Index </b></h2><ul>");
        /*
         * Looping over all of the items in sortedTerms
         */
        while (sortedTerms.length() > 0) {
            /*
             * Outputting the name of the terms alphabetically in the index and
             * with a hyperlink that sends the user to a page with the
             * definition of the term
             */
            currentTerm = sortedTerms.dequeue();
            processSingleTerm(folderName + "/" + currentTerm + ".html",
                    currentTerm, termsAndDefinitions, sortedTerms);
            out.println("<li><a href = " + currentTerm + ".html" + ">"
                    + currentTerm + "</a></li>");
            testQueue.enqueue(currentTerm);
        }
        /*
         * Restoring all of the items that were in sortedTerms
         */
        sortedTerms.transferFrom(testQueue);
        out.println("</ul></body></html>");

        out.close();
    }

    /**
     * Outputs the index html page with the hyperlinks of each term
     * corresponding to an html file that contains the term and its definition.
     *
     * @param termsAndDefinitions
     *            The map that contains the terms and their definitions
     * @param sortedTerms
     *            A queue containing the sorted terms found in the map
     *            termsAndDefinitions
     * @param fileName
     *            The name of the file entered by the user
     * @param term
     *            The term for which an html page will be generated
     *
     * @requires The entered fileName exists, the queue sortedTerms and the map
     *           termsAndDefinitions are both formatted appropriately
     *
     * @ensures The outputted html page for the term is formatted appropriately
     *
     */

    public static void processSingleTerm(String fileName, String term,
            Map<String, String> termsAndDefinitions,
            Queue<String> sortedTerms) {
        /*
         * out is an output stream to a file with the name fileName
         */
        SimpleWriter out = new SimpleWriter1L(fileName);
        /*
         * Properly formatting the page
         */
        if (termsAndDefinitions.hasKey(term)) {
            out.println(
                    "<html> <head> <title>" + term + "</title> </head> <body>");
            out.println(
                    "<h1 style = color:red><b><i>" + term + "</i></b></h1>");
            processDefinition(term, termsAndDefinitions, out);
            out.print("<p>Return to <a href = index.html>index</a>.</p>");
            out.println("</body></html>");
        }
        out.close();
    }

    /**
     * Outputs the index html page with the hyperlinks of each term
     * corresponding to an html file that contains the term and its definition.
     *
     * @param termsAndDefinitions
     *            The map that contains the terms and their definitions
     * @param out
     *            An output stream to a certain file
     * @param term
     *            The term for which an html page will be generated
     *
     * @requires The entered output stream out is open, and the map
     *           termsAndDefinitions is formatted appropriately
     *
     * @ensures The definition to be outputted is formatted appropriately
     *
     */

    public static void processDefinition(String term,
            Map<String, String> termsAndDefinitions, SimpleWriter out) {

        out.print("<p>");

        /*
         * definition is the definition of the term to be processed
         */
        String definition = "";
        if (termsAndDefinitions.hasKey(term)) {
            definition = termsAndDefinitions.value(term);
        }

        /*
         * words is a queue that contains all of the words in the definition of
         * the term at hand
         */
        Queue<String> words = new Queue1L<>();

        /*
         * givenWord is a specific word in definition
         */
        String givenWord = "";

        /*
         * Looping over all of the character in definition
         */
        for (int i = 0; i < definition.length(); i++) {
            /*
             * Finding all of the words and special characters in definition and
             * adding them to the queue words
             */
            if (Character.isLetter(definition.charAt(i))) {
                givenWord += definition.charAt(i);
                if (i == definition.length() - 1) {
                    words.enqueue(givenWord);
                }
            } else {
                if (givenWord.length() > 0) {
                    words.enqueue(givenWord);
                }
                if (definition.charAt(i) != ' ') {
                    words.enqueue(Character.toString(definition.charAt(i)));
                }
                givenWord = "";
            }
        }

        /*
         * Looping over all of the elements in the queue words and adding
         * hyperlinks to other terms that are in the map termsAndDefinitions if
         * needed
         */
        while (words.length() > 0) {
            givenWord = words.dequeue();
            if (termsAndDefinitions.hasKey(givenWord)) {
                out.print(" <a href = " + givenWord + ".html>" + givenWord
                        + "</a>");
            } else {
                if (!Character.isLetter(givenWord.charAt(0))) {
                    out.print(givenWord);
                } else {
                    out.print(" " + givenWord);
                }
            }
        }

        out.print("</p>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Prompting the user for the name of the file containing terms and
         * definitions
         */
        out.println(
                "Enter the name of the file containing terms and their respective definitions: ");
        String fileName = in.nextLine();
        /*
         * Prompting the user for the name of the folder to send the generated
         * files to
         */
        out.println(
                "Enter the name of the folder where all of the files will be outputted: ");
        String folderName = in.nextLine();
        /*
         * Generating the necessary files through method calls
         */
        Map<String, String> termsAndDefinitions = readInput(fileName);
        Queue<String> sortedTerms = sortedTerms(termsAndDefinitions);
        processIndex(sortedTerms, termsAndDefinitions, folderName);

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
